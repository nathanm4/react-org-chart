CREATE DATABASE  IF NOT EXISTS `unicef_org` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `unicef_org`;
-- MySQL dump 10.13  Distrib 8.0.40, for macos14 (arm64)
--
-- Host: localhost    Database: unicef_org
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `people`
--

DROP TABLE IF EXISTS `people`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `people` (
  `id` int NOT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `totalReports` int DEFAULT NULL,
  `hasChild` tinyint(1) DEFAULT NULL,
  `hasParent` tinyint(1) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `people`
--

LOCK TABLES `people` WRITE;
/*!40000 ALTER TABLE `people` DISABLE KEYS */;
INSERT INTO `people` VALUES (25,'URL_TO_EARTH_IMAGE','','Kerry peter','IT Specialist',3,1,1,NULL),(32,'https://randomwordgenerator.com/img/picture-generator/52e4d1424f5aa914f1dc8460962e33791c3ad6e04e5074417d2e72d2954ac5_640.jpg','','Emanuel walker','IT Specialist',0,1,1,NULL),(36,'URL_TO_NATHAN_PICTURE','','Tomasz polaski','IT Specialist',4,1,1,NULL),(45,'URL_TO_AVATAR_PERSONNEL','','Kin baker','IT Officer',0,0,1,NULL),(56,'URL_TO_AVATAR_PERSONNEL','','Sam John','HR',2,1,1,'https://github.com/unicef/react-org-chart'),(60,'URL_TO_AVATAR_PERSONNEL','','Ellen cott','IT Officer',0,0,1,NULL),(66,'URL_TO_AVATAR_PERSONNEL','','John doe','Developer',0,1,1,'https://github.com/unicef/react-org-chart'),(70,'URL_TO_AVATAR_PERSONNEL','','Kenneth dom','IT Officer',0,0,1,NULL),(76,'URL_TO_AVATAR_PERSONNEL','','Emilia rogers','Developer',0,1,1,'https://github.com/unicef/react-org-chart'),(100,'https://media.licdn.com/dms/image/v2/D5603AQFeut-csilJBw/profile-displayphoto-shrink_400_400/profile-displayphoto-shrink_400_400/0/1725427041944?e=1733961600&v=beta&t=0MAv1OyjlbGCYZWRREuKKOs-exkTipE-LoZR6ysbC0I','','Henry monger','Manager',3,1,1,NULL),(102,'URL_TO_AVATAR_PERSONNEL','','Hendy kinger','Manager',0,1,1,NULL),(444,'URL_TO_AVATAR_PERSONNEL','','John medis','IT Officer',0,0,1,NULL),(455,'URL_TO_AVATAR_PERSONNEL','','Kate baker','IT Officer',0,0,1,NULL),(456,'URL_TO_AVATAR_PERSONNEL','','Brett lee','IT Officer',0,0,1,NULL);
/*!40000 ALTER TABLE `people` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-11-08 11:35:07
